# Engineering evidence (Engineer-owned)

Owner: Claudy. The QA lane is `QAM/`; nothing here is independent QA evidence.

- `attempt-001/verification/`: baseline and final command logs, plus `SUMMARY.txt` (cwd, versions, exit codes) and real-runtime negatives (0 ADK requests).
- `attempt-001/browser/`: Playwright JSON results and screenshots from `tests/workspace/apbm001.config.ts` (synthetic fixture only).
- `attempt-001/live/`: live-walk ledger. Attempt 001 = STOP-AUTH, zero requests.
- `attempt-001/changed-paths.json`: working-tree candidate inventory before Tony's commit (path, git status, role, bytes, SHA-256).
- `tools/apbm001_live_walk.cjs`: bounded live-walk helper (engineering budget enforced fail-closed; credential values never written).

Later attempts go in new `attempt-NNN/` folders; earlier attempts are kept.
