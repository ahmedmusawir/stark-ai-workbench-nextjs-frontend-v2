# Engineering handoff to independent QA — pending Claudy

No implementation or test success is prefilled.

Provide: product candidate (or pending commit with baseline/diff identity); exact changed files; AC-by-AC claims and evidence; commands/cwd and results; setup/runtime/ports; login mechanism without values; actual effective target identity; live budget ledger; fixture/network guard details; browser privacy controls; new recovery data format; legacy consumer changes; regressions; unsupported/deferred behavior; known limits; reproduction steps; evidence package receipt.

Required owner handoff after Tony commits: Claudy releases active checkout writes; Tony creates qa/frontend-apbm-0001 at the committed candidate; Cody records acceptance of ownership and starts Q1. Record actual timestamps and full SHA. Do not invent this handoff now.

---

## Engineering handoff facts — Claudy, 14 October 2026 19:33 Asia/Dhaka (pre-commit)

- **Product candidate:** pending Tony's commit on `frontend-apbm-0001`. Baseline `f0fbf2282737ea3a63fc78d553cd31fc570821d5` plus the working tree in `../../ENGINEERING_EVIDENCE/attempt-001/changed-paths.json`.
- **Changed files, AC claims, commands, consumers, journal format, limits, rollback:** `../../ENGINEERING_REPORT.md` §2–§12.
- **Runtime and ports:**
  - fixture harness on 127.0.0.1:43181 (`tests/workspace/apbm001.config.ts`, synthetic services, fail-closed network guard, no production auth or services bundled);
  - runtime negatives used `next start` on 127.0.0.1:43190, now stopped;
  - no process of this seat remains running.
- **Login mechanism (no values):**
  - the live walk accepts either the ignored, untracked `.env.qa.local` (exactly `APBM001_QA_EMAIL`, `APBM001_QA_PASSWORD`, read to memory only) or interactive sign-in (`--interactive yes`);
  - neither was available, so it ran **0** times.
- **Effective target identity:** expected mode `live`, Supabase ref `rwosuvbufaqwbaukohkk`, greeting_agent `backend_key` `6b99771174a0f203`. **Not observed**, because it requires sign-in.
- **Live budget ledger:** 0 of every engineering budget used. The Q2 budget is untouched and separate.
- **Fixture/network guard:**
  - Jest route suites mock `fetch` and the Supabase server client, and assert zero upstream on every rejection;
  - Playwright routes abort any non-origin browser request, and `network-guard.cjs` denies non-loopback Node traffic in the harness;
  - the harness build refuses `services/`, `utils/supabase`, `useAuthStore`, `productionAdapter` and `WorkspaceEntry` imports.
- **Browser privacy:** fixture screenshots contain synthetic data only. The live helper screenshots only the A/B transcript region, records the account as a pseudonym, never records other conversations' titles, and stores no cookies or headers.
- **Recovery data format:** `../../ENGINEERING_REPORT.md` §7.
- **Legacy consumer changes:**
  - `ChatPageContent` was migrated to `HistoryResult`;
  - `chatService.sendMessage` is a documented legacy adapter (explicit create plus one run);
  - `SessionPanel` and `sessionIndexService` are unchanged (outside the workspace).
- **Regressions:** none observed. The full Jest suite, the existing Playwright workspace regression (semantics updated where superseded, §6) and the build all pass.
- **Unsupported/deferred:**
  - rename/archive/delete;
  - cross-device recovery;
  - restart durability;
  - second live target and Hermes;
  - deployment/Gate D.
- **Open blocker:** STOP-AUTH for the engineering live walk (AC011/AC012 engineering evidence). Owner: Tony (supply the login path). Smallest resolution: create `.env.qa.local`, or allow interactive sign-in, then Claudy runs the helper once and exports `APBM001_ENGINEERING_REVIEW_002.zip`.
- **Evidence package:** `APBM001_ENGINEERING_REVIEW_002.zip` (this folder) plus receipt; Downloads copy. Review 001 is kept; it differs only in pre-written timestamps.

**Owner handoff:** not yet. After Tony commits, Claudy records the release of checkout writes with the time and full SHA; Tony creates `qa/frontend-apbm-0001` at that SHA; Cody records acceptance. None of these steps has happened.
