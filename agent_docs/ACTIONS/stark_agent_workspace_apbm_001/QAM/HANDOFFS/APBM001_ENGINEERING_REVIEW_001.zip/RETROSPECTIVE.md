# Lessons to carry forward

14 October 2026 — Director-approved target: engineering two passes plus QAM two passes. Pass 1 is comprehensive recon and approval; additional recon is acceptable when necessary. Pass 2 is continuous execution under the settled contract. Accuracy outranks a numerical shot target. Repair and retest are conditional, not hidden failures or mandatory extra phases.

APBM001 planning lesson: code, runtime config, auth/history ownership, deployed API shapes, metadata needs, timing and bounded live behavior were investigated serially. Future phase-planning recon should ask these together, with initial permissions, budgets, conditional follow-ups and return artifacts. Count preparation and handoff waits as well as execution time. Product delivery remains primary; playbook finalization follows actual experience.

Do not generalize individual online demo claims without evidence. Our standard is explicit scope plus reproducible behavior, independent QA and honest deployment limits.

Engineer/Executor append actual durations, Director touches by purpose, blockers, helper corrections, repairs, false assumptions and reusable improvements. Preserve this initial lesson; do not claim the four-pass target was achieved before measurement.

---

### Engineering pass 2 — Claudy, 14 October 2026

- **Durations:**
  - package check and install: 18:47–18:49;
  - preflight: 18:49–18:55;
  - implementation and tests: 18:55–19:21;
  - build, runtime negatives and final verification: 19:22–19:29;
  - records and packaging: 19:29–19:50 (about 1 h total).
- **Director touches:** one, the launch prompt.
- **Blockers:** STOP-AUTH for the live walk. The launch prompt did not say which of the two login paths Tony intended, and no credential file existed. Stating the login path in the launch would avoid this extra round trip.
- **Helper corrections:** two Playwright test-code fixes. One asserted a ledger entry too early; the other did not clear a stale pending record between scenarios. The product's stale-pending → uncertain behaviour was correct and is now asserted explicitly.
- **One product defect caught by tests before handoff:** the auth-cache relabel threw when storage writes were blocked (now guarded).
- **False assumptions corrected:**
  - the existing `playwright.workspace.config.ts` writes into APBM000 evidence, so APBM001 uses its own config;
  - the 80-character title cut would have made live-walk A/B titles identical, so the markers now lead.
- **Reusable improvement:** route-test harness with a verified-user double, plus a per-route boundary matrix asserting zero upstream calls.
